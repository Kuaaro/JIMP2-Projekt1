#ifndef HUFFMAN_H
#define HUFFMAN_H

#include "weighted_dict.h"

void huffman_on_start(weighted_dict *in, int start); /*Creates dict containing keys with huffman at last position of weighted dict*/

#endif
